# Below the Surface

An interactive engagement summary: a scroll film over one engagement's ledger. Sample data only.

| File | What it is |
|---|---|
| `index.html` | The eleven scenes, in order. All copy that isn't a number lives here. |
| `style.css` | Layout, type and the scene styles. Palette tokens are at the top. |
| `app.js` | The film: WebGL water, canvas lights, the depth gauge, every scene's animation, the ledger and the opt-in sound. |
| `data.js` | Generated. The engagement as data: rows, workstreams, team, quarter-hour units and the derived totals. |
| `tools/generate-data.mjs` | The sample engagement, plus the checks that keep every total consistent. |

## Change the numbers

1. Open `tools/generate-data.mjs` and edit `ENGAGEMENT`, `WS` (workstreams), `CREW` (team and rates) or `WORK` (one line per piece of work, in date order, in quarter-hour increments).
2. From this folder (`cd below-the-surface` first if you're at the repo root), run `node tools/generate-data.mjs`. It prints the totals, and it stops with `CHECK FAILED` and writes nothing if anything doesn't add up.
3. Reload the page.

Any element with `data-v="…"` is filled from the data when the page loads (see the `V` table near the top of `app.js`), so sentences like "covered the first 21.25 hours" stay true when the data changes. The one exception is the storm timeline's cards in `index.html`, which are written by hand: keep them true to the storm's lines in `WORK`.

## Run it

```bash
python3 -m http.server 8000
```

(On Windows, type `python` instead of `python3`.)

Then open <http://localhost:8000>.

Contact Chad at [chad@sharksale.pro](mailto:chad@sharksale.pro) or 818-310-3108 for more info. Text preferred.
