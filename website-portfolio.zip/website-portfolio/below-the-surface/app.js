/* Below the Surface: a scroll film over one engagement's ledger.
   One scroll position drives everything: the water (WebGL), the lights (canvas), the depth gauge
   and every scene. All state is a pure function of scroll, so scrolling back plays it in reverse.
   Every number comes from window.ENGAGEMENT (data.js, built by tools/generate-data.mjs). */
(() => {
'use strict';
const D = window.ENGAGEMENT;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;
const seg = (p, a, b) => clamp((p - a) / (b - a));
const ease = t => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const easeOut = t => 1 - Math.pow(1 - t, 3);
const money = n => '$' + Math.round(n).toLocaleString('en-US');
const hrs = n => String(+n.toFixed(2));
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const small = () => innerWidth < 900;
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTH_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const dateLabel = (d, de) => {
  const f = s => { const [, m, dd] = s.split('-'); return MON[+m - 1] + ' ' + +dd; };
  return de && de !== d ? f(d) + ' – ' + f(de).replace(/^[A-Za-z]+ /, m => (de.slice(5, 7) === d.slice(5, 7) ? '' : m)) : f(d);
};
const longDate = (s, year = true) => { const [y, m, dd] = s.split('-'); return +dd + ' ' + MONTH_FULL[+m - 1] + (year ? ' ' + y : ''); };
const WORDS = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen',
  'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
const words = n => (n < 20 ? WORDS[n] : n < 100 ? TENS[Math.floor(n / 10)] + (n % 10 ? '-' + WORDS[n % 10] : '') : String(n));
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);

/* ------------------------------------------------------------------ data */
const ROWS = D.rows;
const WS = D.ws;
const unitsR = D.units.filter(i => ROWS[i].s === 'R');
const unitsB = D.units.filter(i => ROWS[i].s === 'B');
const cumV = []; { let a = 0; unitsR.forEach(i => { a += ROWS[i].rate * 0.25; cumV.push(a); }); }
const TOTAL_H = D.retainer.h;
const months = new Set(ROWS.map(r => r.d.slice(0, 7))).size;
const sameYear = D.period[0].slice(0, 4) === D.period[1].slice(0, 4);

// every [data-v] in the page is filled from here, so the HTML carries no number of its own outside the hand-written storm cards
const V = {
  'period': longDate(D.period[0], !sameYear) + ' – ' + longDate(D.period[1]),
  'paid$': money(D.paid.amount), 'paid.date': longDate(D.paid.date, false),
  'retainer.h': hrs(D.retainer.h), 'units_r': String(unitsR.length), 'months.words': words(months),
  'bookkeeping.h': hrs(D.bookkeeping.h), 'ws0.h': hrs(WS[0].h), 'ws0.Words': cap(words(WS[0].n)), 'ws0.people': words(WS[0].people),
  'storm.Days': cap(words(D.storm_days)), 'storm$': '$' + D.storm_amount.toLocaleString('en-US', { minimumFractionDigits: 2 }),
  'cost_today': D.cost_today, 'cost_target': D.cost_target, 'crew.Words': cap(words(D.crew.length)),
  'entities.keep': words(D.entities.filter(e => e.k).length), 'entities.go': words(D.entities.filter(e => !e.k).length),
  'multiple$': '$' + D.multiple.toFixed(2), 'per_hour_paid$': money(D.per_hour_paid), 'blended$': money(D.blended),
  'carried$': money(D.carried), 'covered.h': hrs(D.covered_h), 'covered.date': longDate(D.covered_date, false),
  'deposit$': money(D.deposit), 'deposit.open$': money(Math.max(0, D.deposit - D.paid.amount)),
  'deposit.pct': Math.round(Math.min(1, D.paid.amount / D.deposit) * 100) + '%',
  'evergreen$': money(D.evergreen), 'evergreen.half$': money(D.evergreen / 2), 'evergreen.k': '$' + Math.round(D.evergreen / 1000) + 'K',
};
const COUNT = { 'retainer.h': D.retainer.h, 'retainer.n': D.retainer.n, 'retainer.touches': D.retainer.touches,
  'specialists': D.crew.filter(p => p.h > 0).length };
$$('[data-v]').forEach(el => { const v = V[el.dataset.v]; if (v != null) el.textContent = v; });
$$('[data-count-key]').forEach(el => { el.dataset.count = COUNT[el.dataset.countKey]; });
{ const ring = $('[data-ring]'); if (ring) ring.style.setProperty('--v', Math.round(Math.min(1, D.paid.amount / D.deposit) * 100)); }
{ const sp = $('[data-split]'), paidW = D.paid.amount / D.retainer.a * 100;
  if (sp) {
    sp.setAttribute('aria-label', `Of ${money(D.retainer.a)} of work delivered, ${money(D.paid.amount)} is covered by the payment and ${money(D.carried)} is carried by the firm`);
    $('.split__billed', sp).style.setProperty('--w', paidW.toFixed(1) + '%');
    $('.split__carried', sp).style.setProperty('--w', (100 - paidW).toFixed(1) + '%');
  } }

/* ------------------------------------------------------------------ scenes */
let vw = innerWidth, vh = innerHeight, docH = 1, target = scrollY, smooth = scrollY, lastY = -1;
const scenes = $$('[data-scene]').map(el => ({
  el, name: el.dataset.scene, top: 0, h: 1, p: 0, vis: false,
  ins: $$('[data-in]', el).map(x => ({ el: x, at: parseFloat(x.dataset.in) || 0, on: false })),
}));
const S = Object.fromEntries(scenes.map(s => [s.name, s]));

function measure() {
  vw = innerWidth; vh = innerHeight;
  const y = scrollY;
  scenes.forEach(s => {
    const r = s.el.getBoundingClientRect(); s.top = r.top + y; s.h = s.el.offsetHeight;
    const pin = $('.pin', s.el); s.free = !!pin && getComputedStyle(pin).position !== 'sticky';   // unpinned on small screens
  });
  docH = document.documentElement.scrollHeight;
  sizeCanvases(); layoutLights(); buildTicks(); buildBaro(); layoutWeb();
  lastY = -1;
}

/* ------------------------------------------------------------------ water (WebGL) */
const cvW = $('#water');
let gl = null, prog = null, U = {};
const VERT = 'attribute vec2 p;varying vec2 vUv;void main(){vUv=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
const FRAG = `
precision highp float;
uniform vec2 uRes;uniform float uTime,uDepth,uLine,uStorm,uDawn;uniform vec2 uMouse;
varying vec2 vUv;
vec2 h2(vec2 p){p=vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3)));return fract(sin(p)*43758.5453);}
float h1(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
float caus(vec2 p,float t){
  vec2 g=floor(p),f=fract(p);float d1=8.,d2=8.;
  for(int y=-1;y<=1;y++){for(int x=-1;x<=1;x++){
    vec2 o=vec2(float(x),float(y));vec2 r=h2(g+o);
    vec2 q=o+.5+.42*sin(t+6.2831*r)-f;float d=dot(q,q);
    if(d<d1){d2=d1;d1=d;}else if(d<d2){d2=d;}
  }}
  return exp(-(sqrt(d2)-sqrt(d1))*12.);
}
void main(){
  vec2 uv=vUv;float asp=uRes.x/uRes.y;float t=uTime;float x=uv.x*asp;
  float wl=uLine+.0045*sin(x*9.+t*1.3)+.0022*sin(x*23.-t*2.1);
  float px=1.8/uRes.y;float edge=smoothstep(-px,px,uv.y-wl);
  vec3 col;
  // sky: dusk over open water
  float s=clamp((uv.y-wl)/max(.001,1.-wl),0.,1.);
  vec3 hz=vec3(1.,.56,.40),rose=vec3(.72,.32,.43),plum=vec3(.15,.10,.23);
  vec3 sky=mix(hz,rose,smoothstep(0.,.42,s));sky=mix(sky,plum,smoothstep(.32,1.,s));
  vec2 sp=vec2((uv.x-.74)*asp,uv.y-wl-.055);
  sky+=vec3(1.,.74,.52)*exp(-dot(sp,sp)*26.)*.62;
  sky+=vec3(1.,.62,.46)*exp(-max(0.,uv.y-wl)*10.)*.18;
  vec3 dawnSky=mix(vec3(1.,.72,.56),vec3(.16,.40,.47),smoothstep(0.,.7,s));
  sky=mix(sky,dawnSky,uDawn*.8);
  {
    float d=uDepth;float up=smoothstep(0.,1.,uv.y);
    vec3 surf=vec3(.06,.38,.41),mid=vec3(.022,.15,.18),deep=vec3(.005,.04,.055);
    col=mix(surf,mid,smoothstep(0.,.45,d));col=mix(col,deep,smoothstep(.4,1.,d));
    col*=.72+.5*up*(1.-.75*d);
    vec2 cp=vec2(x,uv.y)*2.1+vec2(0.,t*.03);
    cp+=.46*vec2(sin(cp.y*1.2+t*.35),cos(cp.x*1.05-t*.3));
    cp+=.17*vec2(sin(cp.y*3.1-t*.5),cos(cp.x*2.7+t*.45));
    float c1=caus(cp,t*.5),c2=caus(cp*1.7+11.3,t*.72);
    float c=c1*.5+c2*.3+c1*c2*1.8;
    float near=pow(1.-d,2.3)*(.35+.65*up);
    col+=vec3(.55,1.,.88)*c*.28*near;
    float sh=pow(max(0.,sin(x*5.5+sin(x*1.7+t*.21)*1.8+t*.07)),10.);
    sh+=.6*pow(max(0.,sin(x*8.3-t*.05+1.7)),14.);
    col+=vec3(.45,.9,.82)*sh*up*up*.11*pow(1.-d,1.3);
    float under=exp(-max(0.,wl-uv.y)*12.)*step(wl,1.02);
    col+=vec3(1.,.55,.45)*under*.2*(1.-uDawn*.5);
    vec2 sp=vec2(x,uv.y)*70.+vec2(0.,t*.9);vec2 gi=floor(sp),gf=fract(sp)-.5;float r=h1(gi);
    col+=vec3(.6,1.,.9)*step(.982,r)*smoothstep(.12,0.,length(gf-(vec2(r,fract(r*9.1))-.5)*.6))*.34*smoothstep(.15,.7,d);
    vec2 m=vec2((uv.x-uMouse.x)*asp,uv.y-uMouse.y);
    col+=vec3(.25,.85,.72)*exp(-dot(m,m)*14.)*.08*(.4+d);
    col=mix(col,col*vec3(1.4,.72,.64)+vec3(.05,.008,0.),uStorm*.6);
    col=mix(col,vec3(.42,.72,.70)*(.72+.4*up),uDawn*.52);
  }
  col=mix(col,sky,edge);
  col+=vec3(1.,.93,.84)*exp(-abs(uv.y-wl)*uRes.y*.55)*.55*step(wl,1.02);
  vec2 v=uv-.5;col*=1.-dot(v,v)*.6;
  col+=(h1(uv*uRes+fract(t))-.5)*.016;
  gl_FragColor=vec4(col,1.);
}`;
function initGL() {
  try { gl = cvW.getContext('webgl', { antialias: false, depth: false, stencil: false, alpha: false, powerPreference: 'high-performance' }); } catch (e) { gl = null; }
  if (!gl) { document.documentElement.classList.add('no-gl'); cvW.style.display = 'none'; return; }
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  try {
    prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog); if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  } catch (e) { console.warn('water shader:', e); gl = null; document.documentElement.classList.add('no-gl'); cvW.style.display = 'none'; return; }
  gl.useProgram(prog);
  const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  ['uRes', 'uTime', 'uDepth', 'uLine', 'uStorm', 'uDawn', 'uMouse'].forEach(n => (U[n] = gl.getUniformLocation(prog, n)));
}
function drawWater(t, st) {
  if (!gl) return;
  gl.uniform2f(U.uRes, cvW.width, cvW.height);
  gl.uniform1f(U.uTime, reduce ? 12.0 : t);
  gl.uniform1f(U.uDepth, st.depth); gl.uniform1f(U.uLine, st.line);
  gl.uniform1f(U.uStorm, st.storm); gl.uniform1f(U.uDawn, st.dawn);
  gl.uniform2f(U.uMouse, mouse.sx, mouse.sy);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
}

/* ------------------------------------------------------------------ lights (canvas 2D) */
const cvL = $('#life'); const ctx = cvL.getContext('2d');
let DPR = 1;
function sizeCanvases() {
  DPR = Math.min(2, devicePixelRatio || 1);
  cvL.width = Math.round(vw * DPR); cvL.height = Math.round(vh * DPR);
  if (gl) { const k = small() ? .5 : .78; cvW.width = Math.round(vw * k); cvW.height = Math.round(vh * k); gl.viewport(0, 0, cvW.width, cvW.height); }
}
const sprites = {};
function sprite(col) {
  if (sprites[col]) return sprites[col];
  const s = 64, c = document.createElement('canvas'); c.width = c.height = s; const g = c.getContext('2d');
  const gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.12, col); gr.addColorStop(.34, col + '66'); gr.addColorStop(1, col + '00');
  g.fillStyle = gr; g.fillRect(0, 0, s, s); return (sprites[col] = c);
}
let rnd = 7; const rand = () => ((rnd = (rnd * 16807) % 2147483647) / 2147483647);
const lights = unitsR.map((ri, j) => ({ ri, j, b: false, col: WS[ROWS[ri].w].color, ph: rand() * 6.283, sp: .5 + rand() * .9,
  jx: rand() - .5, jy: rand() - .5, ax: rand(), ay: rand(), born: -9, hx: 0, hy: 0, gx: 0, gy: 0 }));
const lightsB = unitsB.map((ri, j) => ({ ri, j, col: WS[ROWS[ri].w].color, ph: rand() * 6.283, gx: 0, gy: 0, ax: rand(), ay: rand() }));
let grid = { cell: 20, x: 0, y: 0, cols: 17, bx: 0, by: 0 };
function layoutLights() {
  const n = lights.length;
  // chronological river, descending with you
  lights.forEach((L, j) => {
    const u = j / Math.max(1, n - 1);
    if (small()) {
      L.hx = vw * (.5 + .32 * Math.sin(u * 8.2 + .6) + L.jx * .1); L.hy = vh * (.16 + .6 * u + L.jy * .03);
    } else {
      const right = vw - (132 + Math.min(72, vw * .05) + 60), left = Math.max(vw * .47, 520);
      const cx = (left + right) / 2, amp = Math.max(40, (right - left) / 2 - 30);
      L.hx = cx + amp * Math.sin(u * 6.4 + .4) + L.jx * 46; L.hy = vh * (.13 + .64 * u) + L.jy * 26;
    }
  });
  // mosaic, grouped by workstream
  const cols = 17, rowsR = Math.ceil(n / cols), rowsB = Math.ceil(lightsB.length / cols);
  const left = small() ? 20 : Math.max(vw * .5, 560), right = small() ? vw - 20 : vw - Math.min(72, vw * .05);
  const areaW = right - left;
  const areaH = small() ? vh * .40 : vh * .7;
  const cell = Math.floor(Math.min(areaW / cols, areaH / (rowsR + rowsB + 1.2), 40));
  const gx0 = small() ? (vw - cell * cols) / 2 : left + (areaW - cell * cols) / 2;
  const totalH = cell * (rowsR + rowsB) + cell * 1.2;
  let gy0 = (vh - totalH) / 2 + cell * .2;
  const slot = $('[data-grid-slot]');
  if (small() && slot) {
    slot.style.setProperty('--gh', Math.ceil(totalH) + 'px');
    const pin = slot.closest('.pin');
    gy0 = slot.getBoundingClientRect().top - pin.getBoundingClientRect().top + cell * .1;
  }
  grid = { cell, x: gx0, y: gy0, cols, bx: gx0, by: gy0 + cell * rowsR + cell * 1.2 };
  const order = lights.map((L, j) => j).sort((a, b) => (ROWS[lights[a].ri].w - ROWS[lights[b].ri].w) || (a - b));
  order.forEach((j, k) => { lights[j].gx = gx0 + (k % cols + .5) * cell; lights[j].gy = gy0 + (Math.floor(k / cols) + .5) * cell; lights[j].slot = k; });
  lightsB.forEach((L, k) => { L.gx = gx0 + (k % cols + .5) * cell; L.gy = grid.by + (Math.floor(k / cols) + .5) * cell; });
}
function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

function drawLights(t, st) {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  ctx.clearRect(0, 0, vw, vh);
  if (st.alpha <= .002) return;
  const k = st.k, m = st.morph, amb = st.amb, tile = m * (1 - amb);
  const mx = mouse.x, my = mouse.y;
  // pass 1: glow
  ctx.globalCompositeOperation = 'lighter';
  for (const L of lights) {
    const lit = L.j < k || st.allLit;
    if (!lit) { L.b = false; continue; }
    if (!L.b) { L.b = true; L.born = t; }
    const dr = reduce ? 0 : 1;
    const hx = L.hx + dr * 7 * Math.sin(t * L.sp + L.ph), hy = L.hy + dr * 9 * Math.cos(t * L.sp * .8 + L.ph * 1.3);
    const ax = L.ax * vw + dr * 14 * Math.sin(t * .23 * L.sp + L.ph), ay = ((L.ay * vh + t * 6 * L.sp) % (vh + 40)) - 20;
    let x = lerp(lerp(hx, L.gx, ease(m)), ax, ease(amb)), y = lerp(lerp(hy, L.gy, ease(m)), ay, ease(amb));
    const dx = x - mx, dy = y - my, dd = Math.sqrt(dx * dx + dy * dy);
    const stir = clamp(1 - dd / 150);
    if (stir > 0 && tile < .5) { x += dx / (dd + 1) * stir * 14; y += dy / (dd + 1) * stir * 14; }
    L.x = x; L.y = y;
    const age = t - L.born, flash = reduce ? 0 : clamp(1 - age / .8);
    const tw = reduce ? 1 : .78 + .22 * Math.sin(t * 2.1 + L.ph * 3);
    const a = st.alpha * (1 - tile) * clamp(tw + stir * .6 + flash);
    if (a > .01) { const s = (14 + 20 * flash + stir * 10) * (1 - amb * .5); ctx.globalAlpha = Math.min(1, a); ctx.drawImage(sprite(L.col), x - s, y - s, s * 2, s * 2); }
  }
  // pass 2: ledger tiles
  if (tile > .01) {
    ctx.globalCompositeOperation = 'source-over';
    const c = grid.cell, s = c * .78, r = Math.max(2, c * .16);
    for (const L of lights) {
      const hover = hovered && hovered.L === L;
      ctx.globalAlpha = st.alpha * tile * (hover ? 1 : .88);
      ctx.fillStyle = L.col; roundRect(L.x - s / 2, L.y - s / 2, s, s, r); ctx.fill();
      if (hover) { ctx.globalAlpha = 1; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); }
    }
    if (st.book > .01) {
      for (const L of lightsB) {
        const hover = hovered && hovered.L === L;
        ctx.globalAlpha = st.alpha * tile * st.book * (hover ? .95 : .55);
        ctx.fillStyle = L.col; roundRect(L.gx - s / 2, L.gy - s / 2, s, s, r); ctx.fill();
        if (hover) { ctx.globalAlpha = 1; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); }
      }
    }
  }
  ctx.globalAlpha = 1;
}

/* ------------------------------------------------------------------ record: legend + tooltip */
const legend = $('[data-legend]');
WS.filter(w => w.s === 'R').forEach(w => {
  const li = document.createElement('li');
  li.innerHTML = `<i style="background:${w.color};color:${w.color}"></i><span>${w.name}</span><em>${hrs(w.h)} h</em>`;
  legend.appendChild(li);
});
const tip = $('[data-tip]'); let hovered = null;
function updateTip(st) {
  hovered = null;
  if (!(st.morph > .92 && st.amb < .05) || mouse.x < 0) { tip.hidden = true; return; }
  const c = grid.cell;
  const hit = (arr, useG) => arr.find(L => Math.abs((useG ? L.gx : L.x) - mouse.x) < c / 2 && Math.abs((useG ? L.gy : L.y) - mouse.y) < c / 2);
  let L = hit(lights, false), book = false;
  if (!L && st.book > .9) { L = hit(lightsB, true); book = !!L; }
  if (!L) { tip.hidden = true; return; }
  hovered = { L };
  const r = ROWS[L.ri], w = WS[r.w];
  tip.innerHTML = `<b style="color:${w.color}">${dateLabel(r.d, r.de)} · ${r.c}</b>${r.x}
    <small>${r.tier} · ${hrs(r.h)} h in this piece of work ${book ? '· bookkeeping, separate agreement' : '· ' + money(r.a)}</small>`;
  tip.hidden = false;
  const tx = Math.min(mouse.x + 18, vw - 320), ty = Math.min(mouse.y + 18, vh - 130);
  tip.style.left = tx + 'px'; tip.style.top = ty + 'px';
}

/* ------------------------------------------------------------------ HUD */
const hud = $('[data-hud]'), hudH = $('[data-hud-h]'), hudV = $('[data-hud-v]'), hudMark = $('[data-hud-mark]'), ticks = $('[data-hud-ticks]');
function buildTicks() {
  ticks.innerHTML = '';
  const H = Math.ceil(TOTAL_H);
  for (let h = 0; h <= H; h++) {
    const s = document.createElement('span'); const f = h / TOTAL_H; if (f > 1.001) break;
    s.style.top = (f * 100) + '%'; if (h % 5 === 0) { s.className = 'major'; const e = document.createElement('em'); e.textContent = h; e.style.top = (f * 100) + '%'; ticks.appendChild(e); }
    ticks.appendChild(s);
  }
  const e = document.createElement('em'); e.textContent = hrs(TOTAL_H); e.style.top = '100%'; e.style.color = 'var(--glow)'; ticks.appendChild(e);
}

/* ------------------------------------------------------------------ count: caption */
const ping = $('[data-ping]'), pingD = $('[data-ping-d]'), pingW = $('[data-ping-w]'), pingX = $('[data-ping-x]'), monthEl = $('[data-month]');
let lastRow = -1, lastHour = 0;
function updateCaption(k) {
  const j = k - 1; if (j < 0) { ping.style.opacity = 0; return; }
  ping.style.opacity = 1;
  const ri = unitsR[Math.min(j, unitsR.length - 1)];
  if (ri !== lastRow) {
    lastRow = ri; const r = ROWS[ri];
    pingD.textContent = dateLabel(r.d, r.de) + ', ' + r.d.slice(0, 4);
    pingW.textContent = r.p + ' · ' + r.tier;
    pingX.textContent = r.x;
    ping.classList.remove('is-flash'); void ping.offsetWidth; ping.classList.add('is-flash');
    monthEl.textContent = MONTH_FULL[+r.d.slice(5, 7) - 1];
  }
}

/* ------------------------------------------------------------------ storm */
const track = $('[data-track]'), nodes = $$('[data-node]'), baro = $('[data-baro]'), baroDot = $('[data-baro-dot]');
let baroLen = 1, hitFired = false;  // the path has pathLength="1", so the dash runs 0..1 whatever the SVG's stretch
function buildBaro() {
  const pts = [];
  for (let i = 0; i <= 100; i++) {
    const u = i / 100;
    let pr = .18;
    pr += .78 * (seg(u, .22, .42) ** 1.6) * (1 - seg(u, .58, .9) * .75);
    pr += .03 * Math.sin(u * 40);
    pts.push((i ? 'L' : 'M') + (u * 1000).toFixed(1) + ' ' + (8 + pr * 100).toFixed(1));
  }
  baro.setAttribute('d', pts.join(' '));
  baroLen = baro.getTotalLength ? baro.getTotalLength() : 1000;
  baro.style.strokeDasharray = 1; baro.style.strokeDashoffset = 1;
}
function updateStorm(p) {
  if (small()) { nodes.forEach(n => n.classList.add('is-on')); return; }
  const q = seg(p, .06, .96);
  const span = Math.max(0, track.scrollWidth - vw * .62);
  track.style.setProperty('--x', (-q * span).toFixed(1) + 'px');
  nodes.forEach(n => { const r = n.getBoundingClientRect(); n.classList.toggle('is-on', r.left + r.width * .3 < vw * .74); });
  baro.style.strokeDashoffset = (1 - q).toFixed(4);
  if (baro.getPointAtLength) {
    const pt = baro.getPointAtLength(baroLen * q), box = baro.ownerSVGElement.getBoundingClientRect(), pin = baroDot.offsetParent.getBoundingClientRect();
    const x = box.left - pin.left + pt.x * box.width / 1000, yy = box.top - pin.top + pt.y * box.height / 120;
    baroDot.style.transform = `translate(${x.toFixed(1)}px,${yy.toFixed(1)}px)`;
  }
  const hit = nodes.find(n => n.classList.contains('node--hit'));
  const on = hit && hit.classList.contains('is-on');
  if (on && !hitFired) { hitFired = true; tone(196, .2, 2.4); } else if (!on) hitFired = false;
}

/* ------------------------------------------------------------------ structure web */
const web = $('[data-web]');
const HUB = { x: 320, y: 320 };
const ENT = D.entities.map(e => ({ ...e }));
const NS = 'http://www.w3.org/2000/svg';
const el = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };
function buildWeb() {
  web.innerHTML = '';
  ENT.forEach(E => { E.ln = el('line', { class: 'ln' + (E.k ? '' : ' go-ln') }, web); });
  const hub = el('g', { class: 'nd hub', transform: `translate(${HUB.x} ${HUB.y})` }, web);
  el('circle', { r: 58 }, hub);
  el('text', { y: -3 }, hub).textContent = D.hub[0];
  el('text', { y: 17 }, hub).textContent = D.hub[1];
  ENT.forEach(E => {
    E.g = el('g', { class: 'nd ' + (E.k ? 'keep' : 'go') }, web);
    el('circle', { r: 13 }, E.g);
    const t1 = el('text', { y: 36 }, E.g); t1.textContent = E.n;
    const t2 = el('text', { y: 54, class: 'sub' }, E.g); t2.textContent = E.s;
  });
}
function layoutWeb() {
  ENT.forEach(E => {
    const a = E.a * Math.PI / 180;
    E.p0 = { x: HUB.x + 228 * Math.cos(a), y: HUB.y + 228 * Math.sin(a) };
    E.p1 = E.k ? { x: HUB.x + 176 * Math.cos(a), y: HUB.y + 176 * Math.sin(a) } : { x: HUB.x + 282 * Math.cos(a), y: HUB.y + 282 * Math.sin(a) };
  });
}
function updateWeb(p) {
  web.classList.toggle('s0', p > .04); web.classList.toggle('s1', p > .16); web.classList.toggle('s2', p > .42);
  const q = ease(seg(p, .42, .72));
  ENT.forEach(E => {
    const x = lerp(E.p0.x, E.p1.x, q), y = lerp(E.p0.y, E.p1.y, q);
    E.g.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)})`);
    const dx = x - HUB.x, dy = y - HUB.y, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L;
    E.ln.setAttribute('x1', (HUB.x + ux * 60).toFixed(1)); E.ln.setAttribute('y1', (HUB.y + uy * 60).toFixed(1));
    E.ln.setAttribute('x2', (x - ux * 15).toFixed(1)); E.ln.setAttribute('y2', (y - uy * 15).toFixed(1));
    E.ln.style.setProperty('--len', Math.ceil(L));
  });
}

/* ------------------------------------------------------------------ crew */
function buildCrew() {
  const box = $('[data-crew]'); const max = Math.max(...D.crew.map(p => p.h + p.hB));
  D.crew.forEach(p => {
    const tot = p.h + p.hB, book = p.h === 0 && p.hB > 0;
    const d = document.createElement('div'); d.className = 'mate';
    d.style.setProperty('--c', p.color || '#5EF2C8');
    d.style.setProperty('--w', (tot / max * 100).toFixed(1) + '%');
    const role = book ? p.tier + ' · separate agreement' : p.tier;
    const extra = p.hB && !book ? `<small>+ ${hrs(p.hB)} h bookkeeping</small>` : '';
    d.innerHTML = `<div class="mate__i">${p.code}</div><div><div class="mate__n">${p.name}</div><div class="mate__r">${role}</div></div>
      <div class="mate__bar"><i></i></div><div class="mate__h"><span>${book ? 'bookkeeping' : money(p.rate) + '/h'}</span><b>${hrs(book ? p.hB : p.h)} h${extra}</b></div>`;
    box.appendChild(d);
  });
}

/* ------------------------------------------------------------------ worth */
const liqA = $('[data-liq="a"]'), liqB = $('[data-liq="b"]'), numA = $('[data-num-a]'), numB = $('[data-num-b]');
function updateWorth(p) {
  const f = easeOut(seg(p, .14, .6));
  liqA.style.setProperty('--fill', (f * Math.min(1, D.paid.amount / D.retainer.a) * 100).toFixed(2));
  liqB.style.setProperty('--fill', (f * 100).toFixed(2));
  numA.textContent = money(f * D.paid.amount); numB.textContent = money(f * D.retainer.a);
}

/* ------------------------------------------------------------------ counters in "below" */
const counters = $$('[data-count]').map(e => ({ e, to: +e.dataset.count, dec: +(e.dataset.dec || 0), t0: -1 }));
function updateCounters(t, on) {
  counters.forEach(c => {
    if (!on) { c.t0 = -1; c.e.textContent = (0).toFixed(c.dec); return; }
    if (c.t0 < 0) c.t0 = t;
    const f = reduce ? 1 : easeOut(clamp((t - c.t0) / 1.6));
    c.e.textContent = (c.to * f).toFixed(c.dec);
  });
}

/* ------------------------------------------------------------------ ledger dialog */
const dlg = $('[data-ledger]');
function buildLedger() {
  const body = $('[data-ledger-body]'), foot = $('[data-ledger-foot]');
  const rows = [...ROWS].sort((a, b) => a.t < b.t ? -1 : 1);
  body.innerHTML = rows.map(r => {
    const w = WS[r.w], bk = r.s === 'B';
    return `<tr class="${bk ? 'bk' : ''}"><td class="d">${dateLabel(r.d, r.de)}</td><td class="d">${r.c}</td>
      <td class="w"><i style="background:${w.color}"></i>${r.x}${bk ? ' <em>(separate agreement)</em>' : ''}</td>
      <td class="n">${r.h.toFixed(2)}</td><td class="n r">${bk ? '—' : money(r.rate)}</td><td class="n">${bk ? 'included' : money(r.a)}</td></tr>`;
  }).join('');
  foot.innerHTML = `<tr><td colspan="3">Retainer agreement, from ${longDate(D.period[0])}</td><td class="n">${D.retainer.h.toFixed(2)}</td><td class="r"></td><td class="n">${money(D.retainer.a)}</td></tr>
    <tr><td colspan="3">Bookkeeping under a separate fixed-fee agreement</td><td class="n">${D.bookkeeping.h.toFixed(2)}</td><td class="r"></td><td class="n">included</td></tr>`;
  const key = document.createElement('tr');
  key.innerHTML = `<td colspan="6" style="color:var(--mist);font-weight:400;font-size:12px">${D.crew.map(p => `${p.code} ${p.name}, ${p.tier}`).join(' · ')}</td>`;
  foot.appendChild(key);
}
$('[data-open-ledger]').addEventListener('click', () => { dlg.showModal ? dlg.showModal() : dlg.setAttribute('open', ''); });
$('[data-close-ledger]').addEventListener('click', () => dlg.close());
dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });

/* ------------------------------------------------------------------ sound (opt-in, synthesized) */
let AC = null, master = null, delay = null, soundOn = false;
const soundBtn = $('[data-sound]'), soundLabel = $('[data-sound-label]');
function startAudio() {
  AC = new (window.AudioContext || window.webkitAudioContext)();
  master = AC.createGain(); master.gain.value = 0; master.connect(AC.destination);
  const len = AC.sampleRate * 4, buf = AC.createBuffer(1, len, AC.sampleRate), d = buf.getChannelData(0);
  let last = 0; for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + .02 * w) / 1.02; d[i] = last * 3.2; }
  const src = AC.createBufferSource(); src.buffer = buf; src.loop = true;
  const lp = AC.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 380; lp.Q.value = .5;
  const lfo = AC.createOscillator(); lfo.frequency.value = .06; const lg = AC.createGain(); lg.gain.value = 140;
  lfo.connect(lg); lg.connect(lp.frequency); lfo.start();
  const ag = AC.createGain(); ag.gain.value = .42; src.connect(lp); lp.connect(ag); ag.connect(master); src.start();
  delay = AC.createDelay(1.5); delay.delayTime.value = .41; const fb = AC.createGain(); fb.gain.value = .34;
  delay.connect(fb); fb.connect(delay); const wet = AC.createGain(); wet.gain.value = .5; delay.connect(wet); wet.connect(master);
}
function tone(freq, vol = .1, dur = 1.6) {
  if (!AC || !soundOn) return;
  const now = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(freq, now); o.frequency.exponentialRampToValueAtTime(freq * .74, now + dur * .9);
  g.gain.setValueAtTime(.0001, now); g.gain.exponentialRampToValueAtTime(vol, now + .015); g.gain.exponentialRampToValueAtTime(.0001, now + dur);
  o.connect(g); g.connect(master); g.connect(delay); o.start(now); o.stop(now + dur + .05);
}
soundBtn.addEventListener('click', () => {
  soundOn = !soundOn;
  if (soundOn && !AC) startAudio();
  if (AC) { AC.resume && AC.resume(); master.gain.cancelScheduledValues(AC.currentTime); master.gain.linearRampToValueAtTime(soundOn ? .9 : 0, AC.currentTime + (soundOn ? 1.2 : .4)); }
  soundBtn.setAttribute('aria-pressed', soundOn); soundLabel.textContent = soundOn ? 'Sound on' : 'Sound off';
  if (soundOn) tone(880, .08, 1.4);
});

/* ------------------------------------------------------------------ hero: the waterline cuts the number */
const wet = $('[data-wet]'), cue = $('[data-cue]'), turb = $('#refract-noise');

/* ------------------------------------------------------------------ input */
const mouse = { x: -999, y: -999, sx: .5, sy: .5 };
addEventListener('pointermove', e => { if (e.pointerType === 'touch') return; mouse.x = e.clientX; mouse.y = e.clientY; mouse.sx = e.clientX / vw; mouse.sy = 1 - e.clientY / vh; }, { passive: true });
addEventListener('pointerleave', () => { mouse.x = mouse.y = -999; });
addEventListener('resize', () => { clearTimeout(measure.t); measure.t = setTimeout(measure, 120); });

/* ------------------------------------------------------------------ the film */
const rail = $('[data-rail]'), topBar = $('[data-top]'), heroLogo = $('.hero__logo');
$$('[data-year]').forEach(e => { e.textContent = new Date().getFullYear(); });
const DEPTH = [['hero', 0, .06], ['below', .06, .36], ['count', .36, .62], ['record', .62, .7], ['storm', .7, .9],
  ['structure', .9, .96], ['crew', .96, .9], ['worth', .9, .78], ['billed', .78, .66], ['keep', .66, .5], ['ascent', .5, .03]];
function state(t) {
  const y = smooth;
  // a pinned scene plays while it is stuck to the screen; a free-flowing one plays as it scrolls into view
  scenes.forEach(s => {
    s.p = s.free ? clamp((y + vh * .85 - s.top) / Math.max(1, s.h)) : clamp((y - s.top) / Math.max(1, s.h - vh));
    s.vis = y + vh > s.top && y < s.top + s.h;
  });
  let depth = 0;
  for (const [n, a, b] of DEPTH) { const s = S[n]; if (s && y + vh * .5 >= s.top) depth = lerp(a, b, s.p); }
  const hp = S.hero.p, bp = S.below.p, ap = S.ascent.p;
  let line = lerp(.42, 1.06, ease(seg(hp, .1, .9)));
  if (y + vh * .5 >= S.below.top) line = lerp(1.06, 1.35, bp);
  if (y + vh * .5 >= S.count.top) line = 1.35;
  if (y + vh * .5 >= S.ascent.top) line = lerp(1.35, .44, ease(seg(ap, .5, 1)));
  const dawn = ease(seg(ap, .35, 1));
  const sp = S.storm.vis ? S.storm.p : (y > S.storm.top ? 1 : 0);
  const storm = S.storm.vis ? Math.pow(clamp(1 - Math.abs(sp - .42) / .3), 1.4) : 0;
  // lights
  const cp = S.count.p, rp = S.record.p;
  const beyondCount = y >= S.count.top + S.count.h - vh;
  const k = beyondCount ? lights.length : Math.floor(seg(cp, .06, .9) * lights.length + (cp > .9 ? 1 : 0));
  const inRec = y >= S.record.top - vh * .2;
  const morph = inRec ? seg(rp, .1, .42) : 0;
  const book = inRec ? ease(seg(rp, .56, .72)) : 0;
  // once the record scene lets go, the tiles dissolve into drifting motes before the storm arrives
  const recEnd = S.record.top + S.record.h - vh;
  const pastRec = y >= recEnd;
  const amb = pastRec ? seg(y - recEnd, 0, vh * .35) : 0;
  let alpha = y + vh > S.count.top ? 1 : 0;
  if (pastRec) alpha = lerp(1, .15, amb);
  if (y + vh * .5 >= S.ascent.top) alpha = .15 * (1 - seg(ap, .1, .6));
  const hudOn = ((y + vh * .5 >= S.below.top && bp > .55) || y >= S.count.top) && y < S.record.top - vh * .15;
  return { depth, line, dawn, storm, k: Math.min(k, lights.length), morph, book, amb, alpha, allLit: y >= S.record.top - vh * .2, hudOn };
}

let started = false;
function frame(now) {
  const t = now / 1000;
  target = scrollY;
  smooth = reduce ? target : lerp(smooth, target, .14);
  if (Math.abs(smooth - target) < .25) smooth = target;
  const st = state(t);

  // reveals
  scenes.forEach(s => s.ins.forEach(o => { const on = s.vis && s.p >= o.at || (!s.vis && smooth > s.top); if (on !== o.on) { o.on = on; o.el.classList.toggle('in', on); } }));
  // hero waterline cut
  if (S.hero.vis || S.below.vis) {
    const waterY = vh * (1 - st.line);
    const r = wet.getBoundingClientRect();
    wet.style.setProperty('--cut', (waterY - r.top).toFixed(1) + 'px');
    if (turb && !reduce) turb.setAttribute('baseFrequency', (0.012 + .002 * Math.sin(t * .9)).toFixed(4) + ' ' + (0.06 + .01 * Math.sin(t * .7 + 1)).toFixed(4));
    cue.style.opacity = 1 - seg(S.hero.p, .02, .12);
  }
  updateCounters(t, S.below.ins.some(o => o.on && o.el.classList.contains('stats')));
  // HUD
  hud.classList.toggle('is-on', st.hudOn);
  const kk = st.allLit ? lights.length : st.k;
  const h = kk * .25, v = kk ? cumV[kk - 1] : 0;
  hudH.textContent = h.toFixed(2); hudV.textContent = money(v);
  hudMark.style.top = (h / TOTAL_H * 100).toFixed(2) + '%';
  S.count.el.classList.toggle('is-counting', small() && S.count.p > .12);
  if (S.count.vis) {
    updateCaption(st.k);
    const hr = Math.floor(h);
    if (hr > lastHour) tone(1046 - st.depth * 380, .07, 1.5);
    lastHour = hr;
  }
  if (S.storm.vis || Math.abs(smooth - S.storm.top) < vh * 2) updateStorm(S.storm.p);
  if (S.structure.vis) updateWeb(S.structure.p);
  if (S.worth.vis) updateWorth(S.worth.p);
  rail.style.transform = `scaleX(${(smooth / Math.max(1, docH - vh)).toFixed(4)})`;
  // the header's own mark (and backdrop) arrives once the hero's large logo, if there is one, has left the screen
  if (topBar) topBar.classList.toggle('is-past-hero', heroLogo ? heroLogo.getBoundingClientRect().bottom < topBar.offsetHeight : smooth > vh * .55);

  drawWater(t, st);
  updateTip(st);
  drawLights(t, st);
  if (!started) { started = true; setTimeout(() => $('[data-loader]').classList.add('is-done'), 350); }
  requestAnimationFrame(frame);
}

/* ------------------------------------------------------------------ boot */
initGL(); buildWeb(); buildCrew(); buildLedger();
measure();
(document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(() => { measure(); });
setTimeout(() => $('[data-loader]').classList.add('is-done'), 2200);
requestAnimationFrame(frame);
window.__film = { S, state: () => state(performance.now() / 1000), measure };
})();
