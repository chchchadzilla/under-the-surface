#!/usr/bin/env node
/* Builds the page's data file (OUTPUT, below) from the sample engagement in this file.
   Everything here is invented for demonstration: no real client, person, firm, matter or amount.
   Edit the tables, run `node tools/generate-data.mjs`, and every scene on the page updates.

   The script stops at the first problem, reports it as "CHECK FAILED: ..." and writes nothing
   (see CHECKS below). Fix it and run again: there may be another. */
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const OUTPUT = 'data.js';   // relative to the folder above tools/

/* ------------------------------------------------------------------ the engagement */
const ENGAGEMENT = {
  title: 'Below the Surface',
  client: 'Sample Client',
  period: ['2025-01-13', '2025-04-25'],
  prepared: '2025-04-28',
  paid: { amount: 6000, date: '2025-01-17' },   // what the client has actually paid
  deposit: 6000,                                 // the initial deposit the agreement sets
  evergreen: 5000,                               // evergreen retainer, topped up when it falls below half
  storm_amount: 8940,                            // the penalty in "the storm" scene
  cost_today: '$11–14K', cost_target: 'under $6K',
  hub: ['The client', 'household'],
  // Structure map: k=1 continues, k=0 is being closed; a = angle around the hub, in degrees.
  entities: [
    { k: 1, a: -70, n: 'Operating company', s: 'S corp · the business' },
    { k: 1, a: -10, n: 'Real-estate LLC', s: 'holds the building' },
    { k: 1, a: 50, n: 'Revocable trust', s: 'now funded' },
    { k: 0, a: 130, n: 'Second LLC', s: 'merged in' },
    { k: 0, a: 190, n: 'Old partnership', s: 'final return filed' },
    { k: 0, a: 250, n: 'Unused business name', s: 'cancelled' },
  ],
};

/* Workstreams. s: R = billed under the retainer, B = bookkeeping under a separate fixed-fee agreement.
   Index 0 is the matter featured in "the storm". */
const WS = [
  { name: 'Payroll tax notice & abatement', short: 'Notice', color: '#FF6B4A', s: 'R' },
  { name: 'Planning meetings & coordination', short: 'Meetings', color: '#5EF2C8', s: 'R' },
  { name: 'Entity cleanup', short: 'Entities', color: '#4FC3F7', s: 'R' },
  { name: 'Trust funding & estate plan', short: 'Trust', color: '#B79CFF', s: 'R' },
  { name: 'Current-year tax returns', short: 'Returns', color: '#FF8FC7', s: 'R' },
  { name: 'Payroll controls', short: 'Payroll', color: '#D4F26A', s: 'R' },
  { name: 'Document intake', short: 'Documents', color: '#F9E27D', s: 'R' },
  { name: 'Bookkeeping', short: 'Bookkeeping', color: '#CFE8F2', s: 'B' },
];
const W = Object.fromEntries(WS.map((w, i) => [w.short, i]));

/* The team. Rates are the hourly rates the (sample) agreement sets for each role. */
const CREW = [
  { code: 'R1', name: 'Representative 1', tier: 'Partner', rate: 560, color: '#B79CFF' },
  { code: 'R2', name: 'Representative 2', tier: 'Senior Tax Manager', rate: 440, color: '#FF8A6B' },
  { code: 'R3', name: 'Representative 3', tier: 'Enrolled Agent', rate: 360, color: '#4FC3F7' },
  { code: 'R4', name: 'Representative 4', tier: 'Operations Manager', rate: 320, color: '#7AA2FF' },
  { code: 'R5', name: 'Representative 5', tier: 'Project Coordinator', rate: 240, color: '#D4F26A' },
  { code: 'R6', name: 'Representative 6', tier: 'Tax Associate', rate: 180, color: '#5EF2C8' },
  { code: 'R7', name: 'Representative 7', tier: 'Client Associate', rate: 160, color: '#F9E27D' },
  { code: 'R8', name: 'Representative 8', tier: 'Bookkeeper', rate: 160, color: '#CFE8F2' },
];

/* Every piece of work, in date order: [date, end date or '', person, hours, workstream, what it was].
   Hours are quarter-hour increments. The storm cards in index.html retell the 'Notice' rows. */
const WORK = [
  ['2025-01-13', '', 'R5', 0.5, 'Meetings', 'Kickoff call: goals, open items and owners agreed'],
  ['2025-01-14', '', 'R8', 1.5, 'Bookkeeping', 'Opening balances tied to bank statements'],
  ['2025-01-14', '', 'R7', 0.5, 'Documents', 'Secure portal set up; document checklist sent'],
  ['2025-01-15', '', 'R6', 0.75, 'Documents', 'Prior-year returns and notices indexed'],
  ['2025-01-16', '', 'R8', 1.25, 'Bookkeeping', 'Chart of accounts simplified for the business'],
  ['2025-01-17', '', 'R7', 0.25, 'Meetings', 'Retainer payment received; welcome packet sent'],
  ['2025-01-20', '', 'R2', 0.75, 'Entities', 'Entity review: what each company holds and why'],
  ['2025-01-21', '', 'R6', 0.5, 'Entities', 'State filings pulled for each entity'],
  ['2025-01-22', '', 'R8', 1.0, 'Bookkeeping', 'Owner draws separated from business expenses'],
  ['2025-01-23', '', 'R3', 0.5, 'Trust', 'Estate documents reviewed: trust signed but never funded'],
  ['2025-01-24', '', 'R5', 0.25, 'Meetings', 'Weekly update to the client'],
  ['2025-01-27', '', 'R7', 0.5, 'Documents', 'Year-end tax forms requested from banks and brokers'],
  ['2025-01-28', '', 'R4', 0.5, 'Payroll', 'Payroll provider access set up; quarterly reports pulled'],
  ['2025-01-29', '', 'R6', 0.5, 'Returns', 'Return organizer prepared for the household'],
  ['2025-01-30', '', 'R1', 0.75, 'Entities', 'Entity strategy review with the client'],
  ['2025-01-31', '', 'R5', 0.5, 'Meetings', 'Month-end status report to the client'],
  ['2025-02-03', '', 'R8', 1.25, 'Bookkeeping', 'Monthly close; reconciliation questions sent'],
  ['2025-02-04', '', 'R2', 0.5, 'Entities', 'Merger path for the second LLC mapped'],
  ['2025-02-04', '', 'R7', 0.5, 'Documents', 'Property tax and insurance statements filed'],
  ['2025-02-05', '', 'R5', 0.25, 'Meetings', 'Weekly update to the client'],
  ['2025-02-06', '', 'R3', 0.75, 'Trust', 'Trust funding checklist: home, accounts, business interests'],
  ['2025-02-07', '', 'R7', 0.5, 'Documents', 'Bank and brokerage 1099s received and filed'],
  ['2025-02-10', '', 'R6', 0.5, 'Entities', 'Old partnership’s final-year records gathered'],
  ['2025-02-11', '', 'R4', 0.5, 'Payroll', 'Payroll deposit schedule confirmed for the year'],
  ['2025-02-12', '', 'R7', 0.25, 'Meetings', 'Called the client to confirm the portal upload'],
  ['2025-02-12', '', 'R5', 0.75, 'Entities', 'Entity filing calendar built'],
  ['2025-02-13', '', 'R2', 0.75, 'Returns', 'Prior-year return reviewed for carryforwards'],
  ['2025-02-14', '', 'R5', 0.5, 'Entities', 'Registered-agent changes scheduled'],
  ['2025-02-18', '', 'R8', 1.0, 'Bookkeeping', 'January books closed'],
  ['2025-02-19', '', 'R7', 0.5, 'Trust', 'Deeds and account titles listed for retitling'],
  ['2025-02-20', '', 'R3', 0.5, 'Entities', 'Tax consequences of the merger confirmed'],
  ['2025-02-21', '', 'R5', 0.25, 'Meetings', 'Weekly update to the client'],
  // the storm
  ['2025-02-24', '', 'R7', 0.25, 'Notice', 'Client’s photo of the payroll tax notice received and logged'],
  ['2025-02-24', '', 'R5', 0.5, 'Notice', 'Notice triaged; enrolled agent assigned the same hour'],
  ['2025-02-25', '', 'R6', 1.0, 'Notice', 'Business account transcripts pulled for every quarter'],
  ['2025-02-25', '', 'R4', 0.5, 'Notice', 'Deposits matched against the payroll provider’s reports'],
  ['2025-02-26', '', 'R3', 0.75, 'Notice', 'Gap found: two quarterly deposits never left the account'],
  ['2025-02-26', '', 'R4', 0.5, 'Notice', 'Provider confirmed it still had the old bank on file'],
  ['2025-02-27', '', 'R7', 0.25, 'Notice', 'Client call: what happened and what comes next'],
  ['2025-02-27', '', 'R2', 0.5, 'Trust', 'Trust funding plan reviewed with the estate attorney'],
  ['2025-02-28', '', 'R3', 0.5, 'Notice', 'Penalty and interest on the notice recomputed and confirmed'],
  ['2025-02-28', '', 'R5', 0.25, 'Notice', 'Response deadline calendared; collection timeline mapped'],
  ['2025-02-28', '', 'R5', 0.5, 'Meetings', 'Month-end status report to the client'],
  ['2025-03-03', '', 'R6', 0.75, 'Notice', 'Missed deposits paid through the federal payment system'],
  ['2025-03-03', '', 'R2', 0.5, 'Notice', 'Payment amounts confirmed before release'],
  ['2025-03-04', '', 'R4', 0.75, 'Notice', 'Bank details corrected with the payroll provider; confirmed in writing'],
  ['2025-03-05', '', 'R6', 0.5, 'Notice', 'Next quarter’s deposits verified on the new account'],
  ['2025-03-06', '2025-03-07', 'R3', 3.0, 'Notice', 'First-time abatement request written, with a reasonable-cause narrative as backup'],
  ['2025-03-07', '', 'R1', 0.5, 'Notice', 'Abatement request reviewed and signed off'],
  ['2025-03-10', '', 'R3', 0.75, 'Notice', 'Request submitted by phone; collection hold placed on the account'],
  ['2025-03-10', '', 'R7', 0.25, 'Notice', 'Submission confirmation filed to the client record'],
  ['2025-03-11', '', 'R5', 0.75, 'Trust', 'Trust funding tracker built: every asset, every title'],
  ['2025-03-12', '', 'R5', 0.25, 'Notice', 'Client update: hold in place, decision expected'],
  ['2025-03-14', '', 'R3', 0.5, 'Notice', 'Abatement granted; penalties removed from the account'],
  ['2025-03-14', '', 'R6', 0.5, 'Notice', 'Updated transcript pulled; account confirmed current'],
  // after the storm
  ['2025-03-17', '', 'R5', 0.25, 'Meetings', 'Weekly update to the client'],
  ['2025-03-18', '', 'R2', 0.75, 'Entities', 'Merger filings coordinated with outside counsel'],
  ['2025-03-19', '', 'R6', 0.5, 'Returns', 'Business return workpapers started'],
  ['2025-03-19', '', 'R6', 0.5, 'Trust', 'Title company documents logged'],
  ['2025-03-20', '', 'R4', 0.5, 'Payroll', 'Dual approval and deposit alerts set up with the provider'],
  ['2025-03-20', '', 'R6', 0.75, 'Payroll', 'Deposit history reconciled for the year'],
  ['2025-03-21', '', 'R3', 0.75, 'Trust', 'Assignment of business interests to the trust prepared'],
  ['2025-03-24', '', 'R7', 0.5, 'Documents', 'Trust funding forms sent to the client for signature'],
  ['2025-03-25', '', 'R2', 0.5, 'Entities', 'Final return for the old partnership prepared'],
  ['2025-03-26', '', 'R6', 0.5, 'Entities', 'Old partnership’s accounts closed; confirmations filed'],
  ['2025-03-27', '', 'R5', 0.5, 'Trust', 'Home retitling coordinated with the title company'],
  ['2025-03-28', '', 'R7', 0.25, 'Meetings', 'Client follow-up: signature status'],
  ['2025-03-31', '', 'R2', 1.0, 'Returns', 'Business return reviewed and finalized'],
  ['2025-03-31', '', 'R5', 0.5, 'Meetings', 'Month-end status report to the client'],
  ['2025-04-01', '', 'R6', 0.75, 'Returns', 'Household return prepared'],
  ['2025-04-02', '', 'R2', 0.75, 'Returns', 'Household return reviewed; estimated-tax plan drafted'],
  ['2025-04-02', '', 'R5', 0.5, 'Returns', 'Return deadlines and signatures tracked'],
  ['2025-04-03', '', 'R7', 0.5, 'Returns', 'Returns sent for e-signature; payment vouchers explained'],
  ['2025-04-04', '', 'R5', 0.25, 'Meetings', 'Weekly update to the client'],
  ['2025-04-07', '', 'R4', 0.5, 'Payroll', 'First-quarter deposits confirmed on time'],
  ['2025-04-08', '', 'R6', 0.5, 'Entities', 'Unused business name registration cancelled'],
  ['2025-04-09', '', 'R3', 0.5, 'Trust', 'Brokerage accounts retitled to the trust'],
  ['2025-04-10', '', 'R5', 0.75, 'Meetings', 'Annual planning meeting prepared'],
  ['2025-04-11', '', 'R2', 0.5, 'Meetings', 'Planning meeting agenda and numbers reviewed'],
  ['2025-04-14', '', 'R2', 0.5, 'Entities', 'Merger effective; new structure confirmed'],
  ['2025-04-15', '', 'R1', 1.25, 'Meetings', 'Annual planning meeting with the client'],
  ['2025-04-15', '', 'R5', 1.25, 'Meetings', 'Annual planning meeting with the client'],
  ['2025-04-16', '', 'R7', 0.5, 'Meetings', 'Planning meeting notes and action list sent'],
  ['2025-04-16', '', 'R3', 0.5, 'Trust', 'Trust funding memo for the client file'],
  ['2025-04-17', '', 'R6', 0.5, 'Documents', 'Signed trust funding forms filed to the client record'],
  ['2025-04-18', '', 'R2', 0.5, 'Returns', 'Estimated-tax vouchers for the year prepared'],
  ['2025-04-21', '', 'R2', 0.5, 'Trust', 'Trust funding status: what’s done, what remains'],
  ['2025-04-22', '', 'R4', 0.5, 'Payroll', 'Quarterly payroll review checklist handed over'],
  ['2025-04-22', '', 'R5', 0.5, 'Trust', 'Trust funding follow-ups scheduled'],
  ['2025-04-23', '', 'R7', 0.5, 'Meetings', 'Client questions answered: next year’s estimates'],
  ['2025-04-24', '', 'R1', 0.75, 'Meetings', 'Engagement review and sign-off'],
  ['2025-04-24', '', 'R7', 0.5, 'Documents', 'Engagement file organized and archived'],
  ['2025-04-25', '', 'R5', 0.25, 'Meetings', 'Quarter-close checklist sent to the team'],
];

/* ------------------------------------------------------------------ CHECKS (and the one way to fail) */
const fail = m => { console.error('CHECK FAILED: ' + m); process.exit(1); };
const where = (row, n) => `WORK line ${n + 1} ("${row[5]}", ${row[0]})`;
const realDate = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s + 'T00:00:00Z'))
  && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s;
for (const [k, v] of [['period start', ENGAGEMENT.period[0]], ['period end', ENGAGEMENT.period[1]], ['paid.date', ENGAGEMENT.paid.date]])
  if (!realDate(v)) fail(`ENGAGEMENT ${k} "${v}" is not a real date like 2025-03-14`);
if (ENGAGEMENT.period[1] < ENGAGEMENT.period[0]) fail('ENGAGEMENT.period ends before it starts');

/* ------------------------------------------------------------------ derive everything else */
const r2 = n => Math.round(n * 100) / 100;
const byCode = Object.fromEntries(CREW.map(p => [p.code, p]));
const perDay = {};
const rows = WORK.map((row, i) => {
  const [d, de, c, h, wsKey, x] = row;
  const p = byCode[c], w = W[wsKey];
  if (!realDate(d) || (de && !realDate(de))) fail(`${where(row, i)}: ${realDate(d) ? de : d} is not a real date like 2025-03-14`);
  if (de && de < d) fail(`${where(row, i)}: the end date ${de} is before the start date`);
  if (d < ENGAGEMENT.period[0] || (de || d) > ENGAGEMENT.period[1]) fail(`${where(row, i)} falls outside ENGAGEMENT.period (${ENGAGEMENT.period.join(' to ')})`);
  if (!p) fail(`${where(row, i)}: no one in CREW has the code "${c}"`);
  if (w == null) fail(`${where(row, i)}: no workstream in WS is called "${wsKey}"`);
  if (typeof h !== 'number') fail(`${where(row, i)}: hours must be a plain number like 0.5, without quotes`);
  if (h <= 0 || Math.abs(h * 4 - Math.round(h * 4)) > 1e-9) fail(`${where(row, i)}: ${h} hours is not a quarter-hour amount (0.25, 0.5, 0.75, 1.0 ...)`);
  if (i > 0 && d < WORK[i - 1][0]) fail(`${where(row, i)} comes before the line above it (${WORK[i - 1][0]}); keep WORK in date order`);
  const s = WS[w].s;
  const k = (perDay[d] = (perDay[d] || 0) + 1);
  return {
    i, d, de: de || d, c, p: p.name, tier: p.tier, h, rate: p.rate, a: s === 'R' ? r2(h * p.rate) : 0, w, s, x,
    n: 1 + (h >= 0.5 ? 1 : 0) + (h >= 1 ? 1 : 0),                         // recorded touches behind the piece of work
    t: `${d}T${String(8 + k).padStart(2, '0')}:${String((i * 7) % 60).padStart(2, '0')}:00`,
  };
});

const R = rows.filter(r => r.s === 'R'), B = rows.filter(r => r.s === 'B');
const sum = (arr, f) => r2(arr.reduce((a, r) => a + f(r), 0));
const retainer = { h: sum(R, r => r.h), a: sum(R, r => r.a), n: R.length, touches: sum(R, r => r.n) };
const bookkeeping = { h: sum(B, r => r.h), n: B.length };
if (!R.length) fail('WORK has no retainer lines');
if (ENGAGEMENT.paid.amount >= retainer.a) fail(`the payment ($${ENGAGEMENT.paid.amount}) must be less than the work delivered ($${retainer.a}); the "difference" scene needs something carried`);

const ws = WS.map((w, wi) => {
  const mine = rows.filter(r => r.w === wi);
  return { ...w, h: sum(mine, r => r.h), a: sum(mine, r => r.a), n: mine.length, people: new Set(mine.map(r => r.c)).size };
});
const storm = rows.filter(r => r.w === 0);
if (!storm.length) fail('the first workstream in WS (the storm) has no WORK lines');
const day = s => Date.parse(s + 'T00:00:00Z') / 864e5;
const storm_days = day(storm.reduce((m, r) => (r.de > m ? r.de : m), storm[0].de)) - day(storm[0].d) + 1;  // counted inclusively

const crew = CREW.map(p => {
  const mineR = R.filter(r => r.c === p.code), mineB = B.filter(r => r.c === p.code);
  return { ...p, h: sum(mineR, r => r.h), a: sum(mineR, r => r.a), n: mineR.length, hB: sum(mineB, r => r.h) };
}).filter(p => p.h + p.hB > 0);

const units = [];
rows.forEach(r => { for (let n = 0; n < Math.round(r.h * 4); n++) units.push(r.i); });

// when did the payment run out? walk the retainer quarter hours in order
let cum = 0, q = 0, covered = null;
for (const i of units) {
  if (rows[i].s !== 'R') continue;
  q++; cum += rows[i].rate * 0.25;
  if (!covered && cum >= ENGAGEMENT.paid.amount - 1e-9) covered = { h: q * 0.25, d: rows[i].d };
}

const out = {
  ...ENGAGEMENT,
  retainer, bookkeeping,
  total: { h: r2(retainer.h + bookkeeping.h) },
  blended: Math.round(retainer.a / retainer.h),
  per_hour_paid: Math.round(ENGAGEMENT.paid.amount / retainer.h),
  multiple: r2(retainer.a / ENGAGEMENT.paid.amount),
  carried: r2(retainer.a - ENGAGEMENT.paid.amount),
  covered_h: covered.h, covered_date: covered.d,
  storm_days,
  ws, crew, rows, units,
};

if (sum(crew, p => p.h) !== retainer.h) fail('crew hours do not add up to the retainer hours');
if (sum(crew, p => p.a) !== retainer.a) fail('crew value does not add up to the retainer value');
if (sum(ws.filter(w => w.s === 'R'), w => w.h) !== retainer.h) fail('workstream hours do not add up to the retainer hours');
if (units.length !== Math.round(out.total.h * 4)) fail('quarter-hour units do not match the total hours');

const here = dirname(fileURLToPath(import.meta.url));
const target = join(here, '..', OUTPUT);
writeFileSync(target,
  '/* Generated by tools/generate-data.mjs. Sample data only; edit the generator, not this file. */\n' +
  'window.ENGAGEMENT=' + JSON.stringify(out) + ';\n');

console.log(`wrote ${target}`);
console.log(`retainer ${retainer.h} h · $${retainer.a.toLocaleString('en-US')} · ${retainer.n} pieces · ${retainer.touches} touches`);
console.log(`bookkeeping ${bookkeeping.h} h · paid $${ENGAGEMENT.paid.amount.toLocaleString('en-US')} · carried $${out.carried.toLocaleString('en-US')}`);
console.log(`blended $${out.blended}/h · paid $${out.per_hour_paid}/h · ${out.multiple}x · payment covered the first ${out.covered_h} h (by ${out.covered_date})`);
console.log(`storm: ${storm_days} days · ${ws[0].n} pieces · ${ws[0].h} h · ${ws[0].people} people`);
console.log('crew:', crew.map(p => `${p.code} ${p.h}h $${p.a}${p.hB ? ` +${p.hB}hB` : ''}`).join(' | '));
console.log('ws:', ws.map(w => `${w.short} ${w.h}h/${w.n}/${w.people}p`).join(' | '));
