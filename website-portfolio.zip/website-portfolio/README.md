# Website portfolio

Websites I've designed and built, each rebuilt here with sample data so the work can be shown without anyone's private information.

**Contact Chad at [chad@sharksale.pro](mailto:chad@sharksale.pro) or 818-310-3108 for more info. Text preferred.**

---

## Below the Surface

![The opening scene: a waterline cuts through the one number the client knows](docs/hero.jpg)

An interactive engagement summary for a professional-services firm. The page draws the work behind a client's bill instead of listing it. A client usually sees one number: what they paid. The page starts there, then scrolls under the waterline and draws every quarter hour of professional time as a point of light. Each scene answers one question a client would ask, in order:

| # | Scene | What it shows |
|---|---|---|
| 1 | **Surface** | The only number a client usually sees: what they've paid. A live WebGL waterline cuts through it. |
| 2 | **Below the waterline** | The engagement at a glance: hours, pieces of work, specialists, recorded touches. |
| 3 | **First light** | One light per quarter hour, in the order the work happened. A depth gauge keeps the running hours and value. |
| 4 | **The record** | The same lights regroup into a mosaic by workstream. Hover any tile for the line item; open the full ledger. |
| 5 | **The storm** | One matter told start to finish as a horizontal timeline, with a barometer line that peaks when the penalty lands. |
| 6 | **The structure** | An animated entity map: what continues pulls in, what's being wound down drifts out. |
| 7 | **The team** | Every person on the file, their role, their rate and their hours. |
| 8 | **What it's worth** | Two vessels fill as you scroll: what was paid versus the value delivered. |
| 9 | **The difference** | Where the payment ran out, and what has been carried since. |
| 10 | **Housekeeping** | Administrative items, kept apart from the story of the work. |
| 11 | **Ascent** | Back to the surface at dawn, with the plan for what comes next. |

<p>
  <img src="docs/first-light.jpg" width="49%" alt="First light: one point of light per quarter hour, descending with the reader">
  <img src="docs/record.jpg" width="49%" alt="The record: the lights regrouped into a mosaic by workstream">
</p>
<p>
  <img src="docs/storm.jpg" width="49%" alt="The storm: one matter as a horizontal timeline">
  <img src="docs/team.jpg" width="49%" alt="The team: one card per person, scaled to hours">
</p>

### How it's built

- **No framework, no build step.** Plain HTML, CSS and JavaScript: four files you can open with any static server.
- **One scroll position drives everything.** The water, the lights, the gauge and every scene are a pure function of how far you've scrolled, so scrolling back plays the film in reverse.
- **WebGL water.** A single fragment shader draws the sky, the waterline, caustics, god-rays and drifting particles, and shifts its color for the storm and the dawn.
- **Canvas 2D lights.** About 200 sprites move between three layouts, a river, a mosaic and ambient drift, by easing between precomputed positions.
- **Web Audio, opt-in.** Sound is synthesized live: low-passed brown noise for the deep, a soft tone for each hour, and a low note when the penalty lands. Nothing is downloaded.
- **Data-driven.** The numbers on the page, including the ones inside sentences, come from one file, `data.js`, which [`tools/generate-data.mjs`](below-the-surface/tools/generate-data.mjs) builds (the storm timeline's cards are the one hand-written exception). The generator refuses to write the file unless the books balance: crew hours equal workstream hours equal ledger hours, and so on.
- **Accessible defaults.** It respects `prefers-reduced-motion`, keeps text as real text, uses a native `<dialog>` for the ledger, and has a mobile layout that unpins the long scenes.

### Run it locally

```bash
cd below-the-surface
python3 -m http.server 8000
```

(On Windows, type `python` instead of `python3`.) Then open <http://localhost:8000>. Any static server works, for example `npx serve .`

### Make it yours

Edit the tables at the top of [`below-the-surface/tools/generate-data.mjs`](below-the-surface/tools/generate-data.mjs) (the engagement, the workstreams, the team and the work log), then run:

```bash
node below-the-surface/tools/generate-data.mjs
```

The page re-draws every scene from the new data. Copy that isn't a number (headlines, the plan) lives in `below-the-surface/index.html`, and so do the storm timeline's cards, which are written by hand: keep their dates and people true to the storm's lines in the work log.

### About the data

Everything here was written for this demo: a household, its small business, a payroll-tax notice, the representatives, the entities, the dates and every dollar. The numbers are deliberate. $6,000 paid against $15,000 of work at a $300 blended rate comes to $2.50 of work for every dollar paid, and the payment runs out at exactly 21.25 hours, in the middle of the storm.

---

Contact Chad at [chad@sharksale.pro](mailto:chad@sharksale.pro) or 818-310-3108 for more info. Text preferred.
